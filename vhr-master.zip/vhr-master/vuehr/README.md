菜单项数据加载成功之后，在前端有几个可以存放的地方：

1. sessionStorage
2. localStorage
**3. vuex**