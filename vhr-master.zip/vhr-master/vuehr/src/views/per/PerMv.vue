<template>
    <div>
        员工调动
    </div>
</template>

<script>
    export default {
        name: "PerMv"
    }
</script>

<style scoped>

</style>